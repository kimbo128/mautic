<?php
return [
    'name' => 'Resend Email Provider',
    'description' => 'Send transactional and marketing emails via Resend API.',
    'version' => '1.0.0',
    'author' => 'Validium AI / Artur Markus',
    'services' => [
        'integrations' => [
            'mautic.integration.resend' => [
                'class' => \MauticPlugin\ResendBundle\Integration\ResendIntegration::class,
                'arguments' => [
                    'mautic.helper.integration',
                    'translator',
                    'logger',
                    'mautic.helper.encryption',
                ],
                'tags' => ['mautic.integration'],
            ],
        ],
        'mail' => [
            'mautic.transport.resend' => [
                'class' => \MauticPlugin\ResendBundle\Transport\ResendTransport::class,
                'arguments' => [
                    'monolog.logger.mautic',
                    'mautic.helper.core_parameters',
                    'translator',
                ],
                'tags' => ['mautic.mailer.transport'],
            ],
        ],
    ],
];

<?php
namespace MauticPlugin\ResendBundle\Transport;
use Mautic\CoreBundle\Mailer\Transport\AbstractTokenArrayTransport;
use Psr\Log\LoggerInterface;

class ResendTransport extends AbstractTokenArrayTransport
{
    private const API_URL = 'https://api.resend.com/emails';
    private LoggerInterface $logger;
    private $params;

    public function __construct(LoggerInterface $logger, $params, $translator)
    {
        $this->logger = $logger;
        $this->params = $params;
    }

    public function sendRawEmail($content, array $toAddresses, array $cc = [], array $bcc = [])
    {
        $apiKey = getenv('RESEND_API_KEY');
        $from = getenv('MAUTIC_EMAIL_FROM') ?: 'info@yourdomain.com';

        foreach ($toAddresses as $to) {
            $payload = [
                'from' => $from,
                'to' => $to,
                'subject' => $content['subject'] ?? 'No subject',
                'html' => $content['body'] ?? '',
            ];

            $ch = curl_init(self::API_URL);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                "Authorization: Bearer {$apiKey}",
                "Content-Type: application/json"
            ]);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);
            $error = curl_error($ch);
            curl_close($ch);

            if ($error) $this->logger->error("Resend error: " . $error);
            else $this->logger->info("Email sent via Resend to {$to}");
        }
        return true;
    }

    public function getTransportType() { return 'resend'; }
}

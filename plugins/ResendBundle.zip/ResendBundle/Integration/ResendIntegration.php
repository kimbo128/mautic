<?php
namespace MauticPlugin\ResendBundle\Integration;
use Mautic\PluginBundle\Integration\AbstractIntegration;

class ResendIntegration extends AbstractIntegration
{
    public function getName(): string { return 'Resend'; }
    public function getDisplayName(): string { return 'Resend Email Provider'; }
    public function getIcon(): string { return 'plugins/ResendBundle/Assets/img/resend.png'; }

    public function getFormSettings(): array
    {
        return [
            'api_key' => [
                'label' => 'Resend API Key',
                'type' => 'text',
                'required' => true,
            ],
            'from_address' => [
                'label' => 'Default From Address',
                'type' => 'text',
                'required' => true,
                'default' => 'info@yourdomain.com'
            ],
        ];
    }
}

<div class="mautic-resend-config">
    <div class="form-group">
        <label>Resend API Key</label>
        <input type="text" name="resend_api_key" class="form-control" placeholder="Enter Resend API Key">
    </div>
    <div class="form-group">
        <label>Default From Address</label>
        <input type="text" name="resend_from_address" class="form-control" value="info@yourdomain.com">
    </div>
</div>

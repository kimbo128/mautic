# Resend Email Provider for Mautic 6.0.6

## Installation
1. Copy `ResendBundle/` into `plugins/` folder of your Mautic installation.
2. In Mautic, go to **Settings → Plugins → Install/Upgrade Plugins**.
3. Activate **Resend Email Provider**.
4. Configure API Key and From Address in the plugin UI.

## Environment variables (optional)
```
RESEND_API_KEY=your_api_key_here
MAUTIC_EMAIL_FROM=info@yourdomain.com
```

<?php
namespace MauticPlugin\ResendBundle;
use Mautic\PluginBundle\Bundle\PluginBundleBase;
class ResendBundle extends PluginBundleBase {}
